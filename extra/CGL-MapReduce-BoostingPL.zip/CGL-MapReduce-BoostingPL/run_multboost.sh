#!/bin/bash

if [ $# -ne 3 ]; then
    echo Usage: [number of boost iterations] [number of map tasks][partition file]
    exit -1
fi


export TWISTER_HOME=${HOME}/twister

cp=$TWISTER_HOME/bin:.

for i in ${TWISTER_HOME}/lib/*.jar;
  do cp=$i:${cp}
done

for i in ${TWISTER_HOME}/apps/*.jar;
  do cp=$i:${cp}
done

java -Xmx1000m -Xms512m -XX:SurvivorRatio=10 -classpath $cp cgl.imr.samples.multboost.MultBoost $1 $2 $3

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package csvtosplitarff;

import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;
import weka.core.converters.CSVLoader;
import weka.core.converters.ArffLoader;
import weka.core.Instances;
import weka.core.Instance;
import weka.core.Utils;
import java.io.IOException;
import java.util.Random;

public class CsvToSplitArff {

    private String csvfname;
    private int numSplit;
    private Instances data;
    private String filePath;
    private String filePrefix;
    private String header;
    private String dataString;
    private String arffString;
    private int numAtt;
    private int classIndex;

    public CsvToSplitArff(String f, int num){
        csvfname = f;
        numSplit = num;
        filePath = csvfname.substring(0, csvfname.lastIndexOf(".csv"));
    }

    public void getCsvData(){
        try{
            File file = new File(csvfname);
            filePrefix = file.getName();
            filePrefix = filePrefix.substring(0, filePrefix.lastIndexOf(".csv"));
            CSVLoader csv = new CSVLoader();
            csv.setSource(file);
            data = csv.getDataSet();

            numAtt = data.numAttributes();

            // setting class attribute if the data format does not provide this information
            if (data.classIndex() == -1)
                data.setClassIndex(numAtt-1);

            classIndex = data.classIndex();
        } catch (Exception e){
            new IOException("Some IO problem here!!!!");
        }
    }

    public void setHeader(){
        header = new String("@relation "+filePrefix+"\n\n");
        int i;
        for (i=0; i<numAtt-1; i++)
            header = header.concat("@attribute a"+i+" numeric"+"\n");
        header = header.concat("@attribute a"+i+" {");

        double [] attVals = data.attributeToDoubleArray(classIndex);
        int n = data.numDistinctValues(classIndex);
        int [] sorted = Utils.sort(attVals);
        int prev = Integer.MIN_VALUE;
        int counter = n;
        for (i=0; i<sorted.length && counter>0 ; i++){
            Instance current = data.instance(sorted[i]);
            if ((i == 0) || (current.value(classIndex) > prev)) {
                prev = (int)current.value(classIndex);
                header = header.concat(prev+",");
                counter--;
            }
        }
        header= header.substring(0, header.lastIndexOf(','));
        header = header.concat("}\n\n@data\n");
    }

    public void setDataString(){
        dataString = data.toString();
        dataString = dataString.substring(dataString.lastIndexOf("@data")+6);
    }

    public void saveArff(){
        arffString = header.concat(dataString);
        arffString.trim();
        try{
            File file = new File(filePath+".arff");
            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            out.write(arffString);
            out.close();
        } catch (Exception e){
            new IOException("Some IO problem here!!!!");
        }
    }

    public void getArffData(){
        try{
            File file = new File(filePath+".arff");
            ArffLoader arff = new ArffLoader();
            arff.setSource(file);
            data = arff.getDataSet();
            // setting class attribute if the data format does not provide this information
            if (data.classIndex() == -1)
                data.setClassIndex(data.numAttributes() - 1);
        } catch (Exception e){
            new IOException("Some IO problem here!!!!");
        }
    }

    public void split(){
        data.randomize(new Random(1));
        if (data.classAttribute().isNominal())
            data.stratify(numSplit);
        Instances split;
        for (int i=0; i<numSplit; i++){
            split = data.testCV(numSplit, i);
            String s = split.toString();
            s = s.substring(s.lastIndexOf("@data")+6);
            String p = new String(split.numInstances()+"\n"+split.numAttributes()+"\n");
            s = p.concat(s);
            s = s.replace(',', ' ');
            s = s.trim();

            try{
                File file = new File(filePath+"_"+numSplit+"_"+i+".txt");
                BufferedWriter out = new BufferedWriter(new FileWriter(file));
                out.write(s);
                out.close();
            } catch (Exception e){
                new IOException("Some IO problem here!!!!");
            }
        }
    }

    public void genSingleTwisterFile(){
        String s = new String(data.numInstances()+"\n"+data.numAttributes()+"\n");
        s = s.concat(dataString);
        s = s.replace(',', ' ');
        s = s.trim();

        try{
            File file = new File(filePath+".txt");
            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            out.write(s);
            out.close();
        } catch (Exception e){
            new IOException("Some IO problem here!!!!");
        }
    }
}

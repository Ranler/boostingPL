/* To convert csv file to single arff just comment out
 * last two lines after saveArff(). To get a single Twister
 * File uncomment genSingleTwisterFile() and comment out
 * next three lines.
 */

package csvtosplitarff;

public class MakeSplit {
    public static void main(String[] args) {
        if (args.length != 2) {
                String errorReport = "CsvToSpitArff: the Correct arguments are \n"
                                + "java csvtosplitarff.MakeSplit "
                                + "<num split> <csv file>";
                System.out.println(errorReport);
                System.exit(0);
        }
        int numSplit = Integer.parseInt(args[0]);
        String csvfname = args[1];

//        String csvfname = new String("/home/indranil/data/sonar.csv");//***************************
//        int numSplit = 3;//***************************************************

        CsvToSplitArff ctsa = new CsvToSplitArff(csvfname, numSplit);
        ctsa.getCsvData();
            System.out.println("CSV data loaded for: "+csvfname);
        ctsa.setHeader();
            System.out.println("ARFF header set for: "+csvfname);
        ctsa.setDataString();
            System.out.println("ARFF data set for: "+csvfname);
        ctsa.saveArff();
            System.out.println("ARFF file created for: "+csvfname);
        ctsa.genSingleTwisterFile();
            System.out.println("TXT file created for: "+csvfname);
        ctsa.getArffData();
            System.out.println("ARFF file loaded for: "+csvfname);
        ctsa.split();
            System.out.println(numSplit+" Split(s) created for: "+csvfname);
    }
}
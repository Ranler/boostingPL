#!/bin/bash

if [ $# -ne 4 ]; then
    echo Usage: [num boost iterations] [num Folds] [arff f] [num workers]
    exit -1
fi


export my_HOME=${HOME}/Evaluate

cp=$my_HOME:.

for i in ${my_HOME}/*.jar;
  do cp=$i:${cp}
done

java -Xmx2000m -Xms1000m -XX:SurvivorRatio=10 -classpath $cp RunLogitBoostParaEvaluate $1 $2 $3 $4

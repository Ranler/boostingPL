package cgl.imr.samples.multboost;

import java.util.List;

import cgl.imr.base.Key;
import cgl.imr.base.ReduceOutputCollector;
import cgl.imr.base.ReduceTask;
import cgl.imr.base.SerializationException;
import cgl.imr.base.TwisterException;
import cgl.imr.base.Value;
import cgl.imr.base.impl.JobConf;
import cgl.imr.base.impl.ReducerConf;
import cgl.imr.types.BytesValue;
import cgl.imr.types.DoubleVectorData;

/**
 * Reduce for MultBoost.
 *
 * @author Indranil Palit (indranilpalit@gmail.com)
 *
 */
public class MultBoostReduceTask implements ReduceTask {

	public void close() throws TwisterException {
		// TODO Auto-generated method stub
	}

	public void configure(JobConf jobConf, ReducerConf reducerConf)
			throws TwisterException {
	}

	public void reduce(ReduceOutputCollector collector, Key key,
			List<Value> values) throws TwisterException {

		if (values.size() <= 0) {
			throw new TwisterException("Reduce input error: no values.");
		}
		try {
			BytesValue val = (BytesValue) values.get(0);
			DoubleVectorData in = new DoubleVectorData();
			in.fromBytes(val.getBytes());

			int width = in.getVecLen();
                        int numMapTasks = values.size();
                        double[][] outDouble = new double[numMapTasks][width];
                        double[][] tmp;
                        
                        DoubleVectorData inReduce = null;
                        for (int i = 0; i < numMapTasks; i++) {
                                val = (BytesValue) values.get(i);
                                inReduce = new DoubleVectorData();
                                inReduce.fromBytes(val.getBytes());
                                tmp = inReduce.getData();

                                for (int k = 0; k < width; k++)
                                    outDouble[i][k] = tmp[0][k];
                        }
                        
			DoubleVectorData out = new DoubleVectorData(
					outDouble, outDouble.length, outDouble[0].length);
			collector.collect(key, new BytesValue(out.getBytes()));
		} catch (SerializationException e) {
			throw new TwisterException(e);
		}
	}
}
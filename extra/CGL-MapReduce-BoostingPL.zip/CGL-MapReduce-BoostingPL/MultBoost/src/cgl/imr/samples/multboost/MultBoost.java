package cgl.imr.samples.multboost;

import org.safehaus.uuid.UUIDGenerator;

import cgl.imr.base.TwisterModel;
import cgl.imr.base.TwisterMonitor;
import cgl.imr.base.impl.JobConf;
import cgl.imr.client.TwisterDriver;
import cgl.imr.types.DoubleVectorData;

/**
 * Implements MultBoost algorithm using MapReduce programming model.
 * The MapReduce algorithm we used is shown below. (Assume that the input is
 * already partitioned and available in the compute nodes).
 *
 * @author Indranil Palit (indranilpalit@gmail.com)
 */
public class MultBoost {

	public static String DATA_FILE_SUFFIX = ".txt";
	public static int NUM_LOOPS = 3;
	public static String PROP_VEC_DATA_FILE = "prop_vec_data_file";
	public static int THRESHOLD = 1;

        private static double maxSum = 0.0;

	/**
	 * Main program to run MultBoost.
	 *
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		if (args.length != 3) {
			String errorReport = "MultBoost: the Correct arguments are \n"
					+ "java cgl.imr.samples.kmeans.MultBoost "
					+ "<num boost iterations> <num map tasks> <partition file>";
			System.out.println(errorReport);
			System.exit(0);
		}
		int numIterations = Integer.parseInt(args[0]);
		int numMapTasks = Integer.parseInt(args[1]);
		String partitionFile = args[2];

		MultBoost client;
		try {
			client = new MultBoost();
			double beginTime = System.currentTimeMillis();
			client.driveMapReduce(partitionFile, numMapTasks, numIterations);
			double endTime = System.currentTimeMillis();
			System.out
					.println("------------------------------------------------------");
			System.out.println("MultBoost took "
					+ (endTime - beginTime) / 1000 + " seconds.");
			System.out
					.println("------------------------------------------------------");
                        System.out.println("The slowest worker time: "+maxSum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

	private UUIDGenerator uuidGen = UUIDGenerator.getInstance();

	public void driveMapReduce(String partitionFile, int numMapTasks,
			int numIterations) throws Exception {
		//long beforeTime = System.currentTimeMillis();
		int numReducers = 1; // we need only one reducer for the above

		// JobConfigurations
		JobConf jobConf = new JobConf("MultBoost-map-reduce"
				+ uuidGen.generateRandomBasedUUID());
		jobConf.setMapperClass(MultBoostMapTask.class);
		jobConf.setReducerClass(MultBoostReduceTask.class);
		jobConf.setCombinerClass(MultBoostCombiner.class);
		jobConf.setNumMapTasks(numMapTasks);
		jobConf.setNumReduceTasks(numReducers);

		TwisterModel driver = new TwisterDriver(jobConf);
		driver.configureMaps(partitionFile);
                
		TwisterMonitor monitor = null;

		@SuppressWarnings("unused")
		
                int i,j,k;
                double epsPlus = (double)numMapTasks;
                double epsMinus = 0.0;
                double epsZero = 0.0;
                double delta = 0.000001;
                DoubleVectorData phase1out, phase1in, phase2out, phase2in;
                double phase1outDouble[][] = new double[1][4];
                double weakHyp[][][] = new double[numIterations][numMapTasks][3];
                double alpha[] = new double[numIterations];
                double[][] tmp, eps;
                for ( i = 0; i < numIterations; i++) {
                    phase1outDouble[0][0] = i;
                    phase1outDouble[0][1] = epsPlus;
                    phase1outDouble[0][2] = epsMinus;
                    phase1outDouble[0][3] = epsZero;
                    phase1out = new DoubleVectorData(phase1outDouble, phase1outDouble.length, phase1outDouble[0].length);
                    monitor = driver.runMapReduceBCast(phase1out);
                    monitor.monitorTillCompletion();

                    phase1in = ((MultBoostCombiner) driver.getCurrentCombiner()).getResults();
                    tmp = phase1in.getData();
                    double maxLearningTime = -1.0;
                    for(j=0; j<tmp.length; j++){
                        for(k=0; k<tmp[0].length-1; k++){
                            weakHyp[i][j][k] = tmp[j][k];
                        }
                        maxLearningTime = Math.max(maxLearningTime, tmp[j][k]);
                    }
                    maxSum += maxLearningTime;

                    phase2out = new DoubleVectorData(weakHyp[i], weakHyp[i].length, weakHyp[i][0].length);
                    monitor = driver.runMapReduceBCast(phase2out);
                    monitor.monitorTillCompletion();

                    phase2in = ((MultBoostCombiner) driver.getCurrentCombiner()).getResults();
                    eps = phase2in.getData();
                    epsPlus = 0.0;
                    epsMinus = 0.0;
                    maxLearningTime = -1.0;
                    for (j=0; j<eps.length; j++){
                        epsPlus += eps[j][0];
                        epsMinus += eps[j][1];
                        maxLearningTime = Math.max(maxLearningTime, eps[j][2]);
                    }
                    maxSum += maxLearningTime;
                    epsZero = 1.0 - epsPlus - epsMinus;
                    epsPlus += delta;
                    epsMinus += delta;
                    alpha[i] = (Math.log(epsPlus/epsMinus))/2.0;

                    //System.out.println("Loop "+i+" Completes.");
		}
		//double timeInSeconds = ((double) (System.currentTimeMillis() - beforeTime)) / 1000;
                // Print the test statistics
                for (i=0; i<weakHyp.length; i++){
                    System.out.println("Iteration : "+i+"\tAlpha : "+alpha[i]);
                    for (j=0; j<weakHyp[0].length; j++){
                        for (k=0; k<weakHyp[0][0].length; k++){
                            System.out.print(weakHyp[i][j][k]+"\t");
                        }
                        System.out.println();
                    }
                }
		//System.out.println("Total Time for MultBoost : " + timeInSeconds);
		// Close the TwisterDriver. This will close the broker connections and
		driver.close();
	}
}
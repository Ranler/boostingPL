package cgl.imr.samples.multboost;

import cgl.imr.base.Key;
import cgl.imr.base.MapOutputCollector;
import cgl.imr.base.MapTask;
import cgl.imr.base.SerializationException;
import cgl.imr.base.TwisterException;
import cgl.imr.base.Value;
import cgl.imr.base.impl.JobConf;
import cgl.imr.base.impl.MapperConf;
import cgl.imr.data.file.FileData;
import cgl.imr.types.BytesValue;
import cgl.imr.types.DoubleVectorData;
import cgl.imr.types.StringKey;

/**
 * Map task for the PLBoost
 *
 * @author Indranil Palit (indranilpalit@gmai.com)
 *
 */
public class MultBoostMapTask implements MapTask {

	private FileData fileData;
	private DoubleVectorData vectorData;
        private int numData;
        private int vecLen;
        private int classIndex;
        private double data[][];
        private double sdata[];
        private int sindex[];
        private double w[];
        private int flag[];
        private double thisthresh = 0.0;
        private double thissign = 0.0;
        private double thiswterr = 0.0;
        private double bestwterr = 0.0;
        private double bestthresh = 0.0;
        private double bestsign = 0.0;
        private double bestaxis = 0.0;
        private double phaseTime1 = 0.0;
        private double phaseTime2 = 0.0;

	public void close() throws TwisterException {
		// TODO Auto-generated method stub
	}

	/**
	 * Used to load the vector data from files. Since the mappers are cached
	 * across iterations, we only need to load this data from file once for all
	 * the iterations.
	 */
	public void configure(JobConf jobConf, MapperConf mapConf)
			throws TwisterException {
		double startTime = System.currentTimeMillis();
                
                this.vectorData = new DoubleVectorData();
		fileData = (FileData) mapConf.getDataPartition();

		try {
			vectorData.loadDataFromTextFile(fileData.getFileName());
		} catch (Exception e) {
			throw new TwisterException(e);
		}
                data = vectorData.getData();
                numData = vectorData.getNumData();
                vecLen = vectorData.getVecLen();
                //find array index of class labels
                classIndex = vecLen-1;
                //initial uniform weight assignment
                w = new double[numData];
                //initialize flag
                flag = new int[numData];
                //we donot need to convert labels to 0,1; they are already so.
                double finishTime = System.currentTimeMillis();
                phaseTime1 = (finishTime - startTime)/1000.00;
	}

	/**
	 * Map function for the MultBoost.
	 */
	public void map(MapOutputCollector collector, Key key, Value val)
			throws TwisterException {

                double startTime = System.currentTimeMillis();
                
                DoubleVectorData in = new DoubleVectorData();

		try {
			in.fromBytes(val.getBytes());
			double[][] inDouble = in.getData();

                        int width = inDouble[0].length;
                        if (width == 4){
                            if (inDouble[0][0] == 0.0){
                                double iw = 1.0/(double)(numData*inDouble[0][1]);
                                for(int i=0; i<numData; i++)
                                    w[i] = iw;
                            }
                            else
                                updateW(inDouble[0][1], inDouble[0][2], inDouble[0][3]);

                            decisionStump();
                            double[][] weakHyp = new double[1][4];
                            weakHyp[0][0] = bestaxis;
                            weakHyp[0][1] = bestthresh;
                            weakHyp[0][2] = bestsign;
                            
                            double finishTime = System.currentTimeMillis();
                            phaseTime2 = (finishTime - startTime)/1000.00;                           
                            weakHyp[0][3] = (inDouble[0][0] == 0.0)?phaseTime1+phaseTime2:phaseTime2;

                            DoubleVectorData out = new DoubleVectorData(weakHyp, weakHyp.length, weakHyp[0].length);
                            // This algorithm uses only one reduce task, so we only need one
                            // key.
                            collector.collect(new StringKey("MultBoost-map-to-reduce-key"), new BytesValue(out.getBytes()));
                        }
                        else {
                            double[][] eps = new double[1][3];
                            double[] tmp = new double[2];
                            tmp = evaluateCompositeHyp(inDouble);
                            eps[0][0] = tmp[0];
                            eps[0][1] = tmp[1];

                            double finishTime = System.currentTimeMillis();
                            phaseTime2 = (finishTime - startTime)/1000.00;
                            eps[0][2] = (inDouble[0][0] == 0.0)?phaseTime1+phaseTime2:phaseTime2;

                            DoubleVectorData out = new DoubleVectorData(eps, eps.length, eps[0].length);
                            // This algorithm uses only one reduce task, so we only need one
                            // key.
                            collector.collect(new StringKey("MultBoost-map-to-reduce-key"), new BytesValue(out.getBytes()));                            
                        }
		} catch (SerializationException e) {
			throw new TwisterException(e);
		}
	}
        public double[] evaluateCompositeHyp(double[][] weakHyp){
            double eps[] = new double[2];
            for (int i=0; i<eps.length; i++)
                eps[i] = 0.0;
            for(int i=0; i<numData; i++){
                double sum = 0.0;
                for(int j=0; j<weakHyp.length; j++){
                    int axis = (int)weakHyp[j][0];
                    double thresh = weakHyp[j][1];
                    double sign = weakHyp[j][2];
                    double val = data[i][axis];
                    double pred = (val<thresh)?sign:-sign;
                    sum += pred;
                }
                double y = data[i][classIndex];
                if (sum > 0.0){
                    if (y == 1.0){
                        eps[0] += w[i];
                        flag[i] = 1;
                    }
                    else{
                        eps[1] += w[i];
                        flag[i] = 2;
                    }
                }
                else if (sum < 0.0) {
                    if (y == 0.0){
                        eps[0] += w[i];
                        flag[i] = 1;
                    }
                    else{
                        eps[1] += w[i];
                        flag[i] = 2;
                    }
                }
                else
                    flag[i] = 0;
            }
            return eps;
        }
        public void updateW(double eps1, double eps2, double eps3){
            double epsPlus = eps1;
            double epsMinus = eps2;
            double epsZero = eps3;
            for (int j=0; j<numData; j++){
                if (flag[j] == 1)
                    w[j] /= ((2.0*epsPlus)+(epsZero*Math.sqrt(epsPlus/epsMinus)));
                else if (flag[j] == 2)
                    w[j] /= ((2.0*epsMinus)+(epsZero*Math.sqrt(epsMinus/epsPlus)));
                else
                    w[j] /= (epsZero+(2*Math.sqrt(epsPlus*epsMinus)));
            }
        }
        public void decisionStump(){
            //find total weight
            double totwt = 0.0;
            for (int i=0; i<numData; i++)
                totwt += w[i];
            //find total weights of label ones'
            double oneswt = 0.0;
            for (int i=0; i<numData; i++)
                if (data[i][classIndex] != 0)
                    oneswt += w[i];
            bestwterr = totwt + 1.0;

            for (int i=0; i<classIndex; i++){
                optthresh(i, totwt, oneswt);
                if (thiswterr < bestwterr) {
                    bestthresh = thisthresh;
                    bestsign = thissign;
                    bestwterr = thiswterr;
                    bestaxis = i;
                }
            }
        }
        public void optthresh(int att, double totwt, double oneswt){
            //sort attribute and index
            sdata = new double[numData];
            sindex = new int[numData];
            for(int i=0; i<numData; i++){
                sdata[i] = data[i][att];
                sindex[i] = i;
            }
            quicksort(sdata, sindex);

            double max = sdata[numData-1];
            thisthresh = (max>0)? 2*max : 0.0;
            double zeroswt = totwt-oneswt;
            thissign = (zeroswt < oneswt) ? +1.0 : -1.0;
            thiswterr = Math.min( zeroswt,oneswt);
            double leftoneswt = 0.0;
            double leftzeroswt=0.0;
            for (int i=0; i<numData-1; i++){
               if (data[sindex[i]][classIndex]!= 0.0)/////////////////
                  leftoneswt += w[sindex[i]];
               else
                  leftzeroswt += w[sindex[i]];
               if (sdata[i+1] != sdata[i]) {
                  if ( (leftoneswt + totwt - oneswt - leftzeroswt) < thiswterr ) {
                     thiswterr = leftoneswt + totwt - oneswt - leftzeroswt;
                     thissign = -1.0;
                     thisthresh = (sdata[i] + sdata[i+1])/2;
                  }
                  if ( (leftzeroswt + oneswt - leftoneswt) < thiswterr ) {
                     thiswterr = leftzeroswt + oneswt - leftoneswt;
                     thissign = +1.0;
                     thisthresh = (sdata[i] + sdata[i+1])/2;
                  }
               }
            }
        }
        public static void quicksort(double[] main, int[] index) {
            quicksort(main, index, 0, index.length - 1);
        }
        // quicksort a[left] to a[right]
        public static void quicksort(double[] a, int[] index, int left, int right) {
            if (right <= left) return;
            int i = partition(a, index, left, right);
            quicksort(a, index, left, i-1);
            quicksort(a, index, i+1, right);
        }
        // partition a[left] to a[right], assumes left < right
        private static int partition(double[] a, int[] index, int left, int right) {
            int i = left - 1;
            int j = right;
            while (true) {
                while (less(a[++i], a[right]))      // find item on left to swap
                    ;                               // a[right] acts as sentinel
                while (less(a[right], a[--j]))      // find item on right to swap
                    if (j == left) break;           // don't go out-of-bounds
                if (i >= j) break;                  // check if pointers cross
                exch(a, index, i, j);               // swap two elements into place
            }
            exch(a, index, i, right);               // swap with partition element
            return i;
        }
        // is x < y ?
        private static boolean less(double x, double y) {
            return (x < y);
        }
        // exchange a[i] and a[j]
        private static void exch(double[] a, int[] index, int i, int j) {
            double swap = a[i];
            a[i] = a[j];
            a[j] = swap;
            int b = index[i];
            index[i] = index[j];
            index[j] = b;
        }
}
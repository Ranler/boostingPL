package cgl.imr.samples.paraboost;

import org.safehaus.uuid.UUIDGenerator;

import cgl.imr.base.TwisterModel;
import cgl.imr.base.TwisterMonitor;
import cgl.imr.base.impl.JobConf;
import cgl.imr.client.TwisterDriver;
import cgl.imr.types.DoubleVectorData;
import cgl.imr.types.IntValue;

/**
 * Implements ParaBoost algorithm using MapReduce programming model.
 * The MapReduce algorithm we used is shown below. (Assume that the input is
 * already partitioned and available in the compute nodes).
 * 
 * @author Indranil Palit (indranilpalit@gmail.com)
 */
public class ParaBoost {

	public static String DATA_FILE_SUFFIX = ".txt";
	public static int NUM_LOOPS = 3;
	public static String PROP_VEC_DATA_FILE = "prop_vec_data_file";
	public static int THRESHOLD = 1;

        private static double maxLearningTime = -1.0;

	/**
	 * Main program to run ParaBoost.
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		if (args.length != 3) {
			String errorReport = "ParaBoost: the Correct arguments are \n"
					+ "java cgl.imr.samples.kmeans.PLBoost "
					+ "<num boost iterations> <num map tasks> <partition file>";
			System.out.println(errorReport);
			System.exit(0);
		}

                int numIterations = Integer.parseInt(args[0]);
		int numMapTasks = Integer.parseInt(args[1]);
		String partitionFile = args[2];

		ParaBoost client;
		try {
			client = new ParaBoost();
			double beginTime = System.currentTimeMillis();
			client.driveMapReduce(partitionFile, numMapTasks, numIterations);
			double endTime = System.currentTimeMillis();
			System.out
					.println("------------------------------------------------------");
			System.out.println("ParaBoost took "
					+ (endTime - beginTime) / 1000 + " seconds.");
			System.out
					.println("------------------------------------------------------");
                        System.out.println("The slowest worker time: "+maxLearningTime);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

	private UUIDGenerator uuidGen = UUIDGenerator.getInstance();

	public void driveMapReduce(String partitionFile, int numMapTasks,
			int numIterations) throws Exception {
		//long beforeTime = System.currentTimeMillis();
		int numReducers = 1; // we need only one reducer for the above

		// JobConfigurations
		JobConf jobConf = new JobConf("ParaBoost-map-reduce"
				+ uuidGen.generateRandomBasedUUID());
		jobConf.setMapperClass(ParaBoostMapTask.class);
		jobConf.setReducerClass(ParaBoostReduceTask.class);
		jobConf.setCombinerClass(ParaBoostCombiner.class);
		jobConf.setNumMapTasks(numMapTasks);
		jobConf.setNumReduceTasks(numReducers);

		TwisterModel driver = new TwisterDriver(jobConf);
		driver.configureMaps(partitionFile);

                IntValue nIterations = new IntValue(numIterations);

		@SuppressWarnings("unused")

                TwisterMonitor monitor = driver.runMapReduceBCast(nIterations);
                monitor.monitorTillCompletion();
                DoubleVectorData sortedHyp = ((ParaBoostCombiner) driver
                                .getCurrentCombiner()).getResults();

                double[][] sortedHypothesis = sortedHyp.getData();
                //double timeInSeconds = ((double) (System.currentTimeMillis() - beforeTime)) / 1000;
		// Print the test statistics
                int i = 0;
                for (i=0; i<numIterations; i++){
                    double sum = 0.0;
                    for (int j=0; j<numMapTasks; j++){
                        for (int k = 0; k < sortedHypothesis[0].length; k++) {
				System.out.print(sortedHypothesis[j*(numIterations+1)+i][k] + "\t");
                        }
                        System.out.println();
                        sum += sortedHypothesis[j*numIterations+i][3];
                    }
                    System.out.println("Iteration "+i+" Merged classifier alpha: "+sum/(double)numMapTasks);
                }
                for (int j=0; j<numMapTasks; j++){
                    maxLearningTime = Math.max(maxLearningTime, sortedHypothesis[j*(numIterations+1)+i][0]);
                }

                System.out.println("ParaBoost Completes.");
		//System.out.println("Total Time for ParaBoost : " + timeInSeconds);
		// Close the TwisterDriver. This will close the broker connections and
		driver.close();
	}
}
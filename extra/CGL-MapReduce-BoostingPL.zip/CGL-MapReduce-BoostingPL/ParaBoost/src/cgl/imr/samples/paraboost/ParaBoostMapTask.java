package cgl.imr.samples.paraboost;

import cgl.imr.base.Key;
import cgl.imr.base.MapOutputCollector;
import cgl.imr.base.MapTask;
import cgl.imr.base.SerializationException;
import cgl.imr.base.TwisterException;
import cgl.imr.base.Value;
import cgl.imr.base.impl.JobConf;
import cgl.imr.base.impl.MapperConf;
import cgl.imr.data.file.FileData;
import cgl.imr.types.BytesValue;
import cgl.imr.types.DoubleVectorData;
import cgl.imr.types.StringKey;
import cgl.imr.types.IntValue;

/**
 * Map task for the ParaBoost
 * 
 * @author Indranil Palit (indranilpalit@gmai.com)
 * 
 */
public class ParaBoostMapTask implements MapTask {

	private FileData fileData;
	private DoubleVectorData vectorData;
        private int numData;
        private int vecLen;
        private int classIndex;
        private double data[][];
        private double sdata[];
        private int sindex[];
        private double w[];
        private double weakHyp[][];
        private int numIterations;
        private double delta = 0.000001;
        private double thisthresh = 0.0;
        private double thissign = 0.0;
        private double thiswterr = 0.0;
        private double bestwterr = 0.0;
        private double bestthresh = 0.0;
        private double bestsign = 0.0;
        private double bestaxis = 0.0;
        private double learningTime = 0.0;


	public void close() throws TwisterException {
		// TODO Auto-generated method stub
	}

	/**
	 * Used to load the vector data from files. Since the mappers are cached
	 * across iterations, we only need to load this data from file once for all
	 * the iterations.
	 */
	public void configure(JobConf jobConf, MapperConf mapConf)
			throws TwisterException {
		double startTime = System.currentTimeMillis();

                this.vectorData = new DoubleVectorData();
		fileData = (FileData) mapConf.getDataPartition();

		try {
			vectorData.loadDataFromTextFile(fileData.getFileName());
		} catch (Exception e) {
			throw new TwisterException(e);
		}
                data = vectorData.getData();
                numData = vectorData.getNumData();
                vecLen = vectorData.getVecLen();
                //find array index of class labels
                classIndex = vecLen-1;
                //initial uniform weight assignment
                w = new double[numData];
                double iw = 1.0/(double)numData;
                for(int i=0; i<numData; i++)
                    w[i] = iw;
                //we donot need to convert labels to 0,1; they are already so.
                double finishTime = System.currentTimeMillis();
                learningTime += (finishTime - startTime)/1000.00;
	}

	/**
	 * Map function for the ParaBoost.
	 */
	public void map(MapOutputCollector collector, Key key, Value val)
			throws TwisterException {

                double startTime = System.currentTimeMillis();
                IntValue nIterations = new IntValue();

		try {
			nIterations.fromBytes(val.getBytes());
			numIterations = nIterations.getVal();

                        weakHyp = new double[numIterations][4];
                        int i,j;
                        for ( i=0; i<numIterations; i++ ){
                            decisionStump();
                            double epsMinus = bestwterr;
                            double epsPlus = 1.0 - epsMinus;
                            epsMinus += delta;
                            epsPlus += delta;
                            for ( j=0; j<numData; j++ ) {
                                double pred = (data[j][(int)bestaxis]<bestthresh)?bestsign:-bestsign;
                                double y = data[j][classIndex];
                                w[j] = (((pred==+1.0) && (y==1.0))||((pred==-1.0) && (y==0.0)))? w[j]/(2*epsPlus):w[j]/(2*epsMinus);
                            }
                            weakHyp[i][0] = bestaxis;
                            weakHyp[i][1] = bestthresh;
                            weakHyp[i][2] = bestsign;
                            weakHyp[i][3] = (Math.log(epsPlus/epsMinus))/2.0;
                        }
                        //sort hypothesis
                        double alpha[] = new double[numIterations];
                        for (i=0; i<alpha.length; i++)
                            alpha[i] = weakHyp[i][3];
                        int index[] = new int[alpha.length];
                        for (i=0; i<index.length; i++)
                            index[i] = i;
                        quicksort(alpha, index);
                        double sortedweakHyp[][] = new double[index.length+1][weakHyp[0].length];
                        for (i=0; i<index.length; i++){
                            int pos = index[i];
                            for (j=0; j<sortedweakHyp[0].length; j++)
                                sortedweakHyp[i][j] = weakHyp[pos][j];
                        }
                        double finishTime = System.currentTimeMillis();
                        learningTime += (finishTime - startTime)/1000.00;
                        sortedweakHyp[i][0] = learningTime;
			DoubleVectorData sortedHypothesis = new DoubleVectorData(sortedweakHyp,
					sortedweakHyp.length, sortedweakHyp[0].length);
			// This algorithm uses only one reduce task, so we only need one
			// key.
			collector.collect(new StringKey("ParaBoost-map-to-reduce-key"),
					new BytesValue(sortedHypothesis.getBytes()));

		} catch (SerializationException e) {
			throw new TwisterException(e);
		}
	}
        public void decisionStump(){
            //find total weight
            double totwt = 0.0;
            for (int i=0; i<numData; i++)
                totwt += w[i];
            //find total weights of label ones'
            double oneswt = 0.0;
            for (int i=0; i<numData; i++)
                if (data[i][classIndex] != 0)
                    oneswt += w[i];
            bestwterr = totwt + 1.0;

            for (int i=0; i<classIndex; i++){
                optthresh(i, totwt, oneswt);
                if (thiswterr < bestwterr) {
                    bestthresh = thisthresh;
                    bestsign = thissign;
                    bestwterr = thiswterr;
                    bestaxis = i;
                }
            }
        }
        public void optthresh(int att, double totwt, double oneswt){
            //sort attribute and index
            sdata = new double[numData];
            sindex = new int[numData];
            for(int i=0; i<numData; i++){
                sdata[i] = data[i][att];
                sindex[i] = i;
            }
            quicksort(sdata, sindex);

            double max = sdata[numData-1];
            thisthresh = (max>0)? 2*max : 0.0;
            double zeroswt = totwt-oneswt;
            thissign = (zeroswt < oneswt) ? +1.0 : -1.0;
            thiswterr = Math.min( zeroswt,oneswt);
            double leftoneswt = 0.0;
            double leftzeroswt=0.0;
            for (int i=0; i<numData-1; i++){
               if (data[sindex[i]][classIndex]!= 0.0)/////////////////
                  leftoneswt += w[sindex[i]];
               else
                  leftzeroswt += w[sindex[i]];
               if (sdata[i+1] != sdata[i]) {
                  if ( (leftoneswt + totwt - oneswt - leftzeroswt) < thiswterr ) {
                     thiswterr = leftoneswt + totwt - oneswt - leftzeroswt;
                     thissign = -1.0;
                     thisthresh = (sdata[i] + sdata[i+1])/2;
                  }
                  if ( (leftzeroswt + oneswt - leftoneswt) < thiswterr ) {
                     thiswterr = leftzeroswt + oneswt - leftoneswt;
                     thissign = +1.0;
                     thisthresh = (sdata[i] + sdata[i+1])/2;
                  }
               }
            }
        }
        public static void quicksort(double[] main, int[] index) {
            quicksort(main, index, 0, index.length - 1);
        }
        // quicksort a[left] to a[right]
        public static void quicksort(double[] a, int[] index, int left, int right) {
            if (right <= left) return;
            int i = partition(a, index, left, right);
            quicksort(a, index, left, i-1);
            quicksort(a, index, i+1, right);
        }
        // partition a[left] to a[right], assumes left < right
        private static int partition(double[] a, int[] index, int left, int right) {
            int i = left - 1;
            int j = right;
            while (true) {
                while (less(a[++i], a[right]))      // find item on left to swap
                    ;                               // a[right] acts as sentinel
                while (less(a[right], a[--j]))      // find item on right to swap
                    if (j == left) break;           // don't go out-of-bounds
                if (i >= j) break;                  // check if pointers cross
                exch(a, index, i, j);               // swap two elements into place
            }
            exch(a, index, i, right);               // swap with partition element
            return i;
        }
        // is x < y ?
        private static boolean less(double x, double y) {
            return (x < y);
        }
        // exchange a[i] and a[j]
        private static void exch(double[] a, int[] index, int i, int j) {
            double swap = a[i];
            a[i] = a[j];
            a[j] = swap;
            int b = index[i];
            index[i] = index[j];
            index[j] = b;
        }
}
package cgl.imr.samples.paraboost;

import java.util.List;

import cgl.imr.base.Key;
import cgl.imr.base.ReduceOutputCollector;
import cgl.imr.base.ReduceTask;
import cgl.imr.base.SerializationException;
import cgl.imr.base.TwisterException;
import cgl.imr.base.Value;
import cgl.imr.base.impl.JobConf;
import cgl.imr.base.impl.ReducerConf;
import cgl.imr.types.BytesValue;
import cgl.imr.types.DoubleVectorData;

/**
 * Reduce for ParaBoost.
 * 
 * @author Indranil Palit (indranilpalit@gmail.com)
 * 
 */
public class ParaBoostReduceTask implements ReduceTask {

	public void close() throws TwisterException {
		// TODO Auto-generated method stub
	}

	public void configure(JobConf jobConf, ReducerConf reducerConf)
			throws TwisterException {
	}

	public void reduce(ReduceOutputCollector collector, Key key,
			List<Value> values) throws TwisterException {

		if (values.size() <= 0) {
			throw new TwisterException("Reduce input error: no values.");
		}
		try {
			BytesValue val = (BytesValue) values.get(0);
			DoubleVectorData inHyp = new DoubleVectorData();
			inHyp.fromBytes(val.getBytes());

			int numData = inHyp.getNumData();
			int lenData = inHyp.getVecLen();
                        int numMapTasks = values.size();

                        double[][] hypList = new double[numData*numMapTasks][lenData];

			DoubleVectorData inHyps = null;
			double[][] tmp;
                        int hypProcessed = 0;
			
			for (int i = 0; i < numMapTasks; i++) {
				val = (BytesValue) values.get(i);
				inHyps = new DoubleVectorData();
				inHyps.fromBytes(val.getBytes());
				tmp = inHyps.getData();

				for (int j = 0; j < numData; j++) 
					for (int k = 0; k < lenData; k++) 
						hypList[j+hypProcessed][k] = tmp[j][k];

                                hypProcessed += numData;
			}

			DoubleVectorData outHypList = new DoubleVectorData(
					hypList, hypList.length, hypList[0].length);
			collector.collect(key, new BytesValue(outHypList.getBytes()));
		} catch (SerializationException e) {
			throw new TwisterException(e);
		}
	}
}
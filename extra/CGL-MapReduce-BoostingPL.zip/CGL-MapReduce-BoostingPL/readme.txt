>At Amazon EC2 first create a single node with 32 bit Suse linux. This first node can be considered the master node.
While selecting sequrity group for node make sure port 22 is enabled. For being Failsafe also enable all ports ranging 0-65535.
When creating more instances try to create them in same zone.

>Open a terminal and login to the master node.

>Install java. Make sure the java version is compatible with the existing linux.

>Configure passwordless ssh:
----------------------------------------------------------------------------------------
An important step to creating a high performance compute cluster is to enable the head node to be able to login into all of the compute nodes without the use of a password. In order for a cluster to be able to run jobs, the head node must be able to ssh into all the machines without the need to authenticate with a passwords. This is accomplished with password-less ssh login for all the nodes. Security concerns aside, you'll only need to create the key on one machine (master node) and copy it to the other nodes.

>>1.Before you create the login keys for the cluster, you will also need to make sure that all of nodes have the exact same user account name.

>>2.with each machine, delete the ".ssh" directory that resides in the home directory for each machine. "cd" to the home directory and remove the ssh directory
	rm -r .ssh

>>3.To create the key, go to the ssh directory in master node and enter the following at the terminal:
	ssh-keygen -t dsa

Important: Don't enter a passphrase, just press the enter key. This will generate a password-less key file under the ".ssh" directory. You should get two files: id_dsa and id_dsa.pub

>>4.Once the key is generated, you can copy the file id_dsa.pub to authorized_keys2
	cp id_dsa.pub authorized_keys2

>>5.Copy this file "authorized_keys2" to each of the nodes under the ".ssh" directory (essentially replacing the original "authorized_keys2" file if one exists). Below is an example of copying the key to other machines:
	scp $HOME/.ssh/authorized_keys2 node1:$HOME/.ssh/authorized_keys2

Note: When copying keys to the other machines, if you did not start out by deleting your old ".ssh" directory and are appending keys to your existing "authorized_keys2" file, be sure that there is only one key per line. If you copy and paste the key from terminal, remove the end of the lines. The keys will otherwise not work properly.

>>6.The nodes are now set up for password-less login from each other. Now lets test the password-less login before we run the our program. To do this:

>>7.From master ssh to every machine in the cluster (including itself) and then log off. Because all of the user accounts are the same for all the nodes, you don not have to use the username to login. It would look something like:
	ssh 192.168.0.1     

>>8.Answer, "yes" to add the RSA key fingerprint for each machine. This should not ask you for a password (it will only ask you if you want to add the RSA key fingerprint). If the machines still ask you to type in the password, then we messed up somehow and password-less ssh is not setup correctly.
----------------------------------------------------------------------------------------

>Install NaradaBrokering: (required only in the master node)
----------------------------------------------------------------------------------------------------
>>Download the latest version of NaradaBrokering from http://www.naradabrokering.org/software.htm

>>You may also be interested to the working installer coming with the package, NaradaBrokering-4.2.2.zip.

>>Unzip the zip file to your home directory.

>>Rename the folder NaradaBrokering-4.2.2 to NaradaBrokering

>>Update the NB_HOME variable in export NaradaBrokering/bin/startbr.sh:
	export NB_HOME=${HOME}/NaradaBrokering

>>Make the two files executable.
	chmod 777 startbr.sh
	chmod 777 stopbr.sh

>>Once this is done please go to the bin directory and start the broker by running startbr.sh To stop the broker you can use stopbr.sh
---------------------------------------------------------------------------------------------------------------------------------------

>Setting up Twister: (required for all nodes, for now just do for master node)
---------------------------------------------------------------------------------------------------------------------------------------
>>Untar the Twister to home directory.
	tar -zxvf twister-0.8.tar.gz

>>Rename the folder twister-0.8 to twister

>>Then set the environment variable named TWISTER_HOME pointing to this directory. You can run the following line in command line:
	export TWISTER_HOME=$HOME/twister

>>You need to create a directory named 'data' in your home. This will contain datasets.

>>Okay, now you need to set few configuration parameters as follows:
1. Open $TWISTER_HOME/bin/twister.properties file and set the correct paths to the following properties according to your system. nodes_file , app_dir, and data_dir
	nodes_file = /root/twister/bin/nodes 	////this points to the file containing list of nodes
	app_dir = /root/twister/apps		////this points to the folder where the applications (AdaBoost.PL, LogitBoost.PL etc) reside
	data_dir = /root/data			////this points to the folder where apps can find their data
	daemons_per_node = 1
	workers_per_daemon = 1

2. Open $TWISTER_HOME/bin/nb.properties file and set broker_host = (to the IP of the machine where you setup NaradaBrokering ie. the master node)
To get IP addr: run ifconfig and the inet addr under eth0 is your IP.

3. Open $TWISTER_HOME/bin/nodes file and add your local IP address to that file. In a single machine setup you should have only one IP address in this file, in the cluster setup this file will have all the IP addresses of the compute nodes.

4. in stimr.sh change 40000 to 1000 in:
	java -Xmx40000m -Xms512m -XX:SurvivorRatio=10 -classpath $cp cgl.imr.worker.TwisterDaemon $1 $2
5. in twister.sh change all mem ref to 100 in:
	java -Xmx2000m -Xms512m -XX:SurvivorRatio=10 -classpath $cp cgl.imr.script.FileDistributor $2 $3
	java -Xmx2000m -Xms512m -XX:SurvivorRatio=10 -classpath $cp cgl.imr.script.FileCollector $2 $3 $4

6. in create_partition_file.sh change the mem refs to 100m.
	java -Xmx2000m -Xms512m -XX:SurvivorRatio=10 -classpath $cp cgl.imr.client.PartitionFileCreator $1 $2 $3

7. Add the following lines in these six files: create_partition_file.sh, kill_all_processes.sh, start_twister.sh, stimr.sh, stop_twister.sh, twister.sh:
	export TWISTER_HOME=$HOME/twister

8. Like before make start_twister.sh, twister.sh and stop_twister.sh executable by:
	chmod 777 filename
9.Start Twister by running:
	$TWISTER_HOME/bin/start_twister.sh
10.Stop Twister by running:
	$TWISTER_HOME/bin/stop_twister.sh
----------------------------------------------------------------------------------------------------------------------------------------

>Cluster Management
----------------------------------------------------------------------------------------------------------------------------------------
1.First configure the master node with java, passwordless ssh(upto step 4), install Naradabrokering as described and install Twister as described. Then you can just make an Image of this master machine in Amazon and use this image to create as many nodes as required. All of them will be configured properly.

2.Okay now you need to set the following properties in one of the compute nodes where you plan to run your applications (master node).
Open $TWISTER_HOME/bin/nodes file and add all the IP addresses of the compute nodes that you need to use.

3.How to Start and stop Twister runtime? (For now only start, stop at very end)
	$TWISTER_HOME/bin/start_twister.sh
	$TWISTER_HOME/bin/stop_twister.sh

4.Example of How to Run AdaBoost.PL on sonar dataset on 3 nodes?
>>create three nodes including master.

>>copy ParaBoost.jar into twister/apps directory in master node. (available in ParaBoost/dist/)

>>Create a directory named 'mydata' at home at master. Create a subdir 'sonar' inside it. Copy 'sonar.csv' here. It is the full dataset.

>>go to home and create a dir named 'splitcsv'. Copy CsvToSplitArff.jar (this will split the dataset: sonar_3_0.txt, sonar_3_1.txt, sonar_3_2.txt) and weka.jar in it.
CsvToSplitArff.jar can be found in code base CsvToSplitArff folder.

>>go to home. copy runsplitcsv.sh here. Make sure it is executable (chmod ..)

>>Split the data set in 3 pieces.
	./runsplitcsv.sh 3 mydata/sonar/sonar.csv

>>create a directory named 'transferDir'. This will hold the data to be distributed among the nodes.

>>Remove any existing files in transferDir:
	rm /root/transferDir/*

>>Copy the splitted datasets into the transfer dir:
	cp /root/mydata/sonar/sonar_3_* /root/transferDir/

>>Go to twister/bin/. Create a sub directory named "sonar" inside the data dir (for all nodes) you specified in $TWISTER_HOME/bin/twister.properties file.
	./twister.sh mkdir sonar
You can also use './twister.sh rmdir sonar' if you need to erase the folder in all nodes.

>>Distribute the splits in all nodes evenly:
	./twister.sh put /root/transferDir/ sonar

>>You need to create a partition file to run the application. Please run the following script in $TWISTER_HOME/bin directory as follows:

	./create_partition_file.sh [common directory][file filter][partition file]
e.g.	./create_partition_file.sh sonar sonar_3_ partition.pf

>>Once the above steps are successful you can simply run the following shell script to run AdaBoost.PL clustering appliction. First copy run_paraboost.sh (make sure executes) into twister/bin in master.

	./run_paraboost.sh [number of iterations][number of map tasks][partition file]
e.g	./run_paraboost.sh 100 3 partition.pf	
After a while you should be able to see the output.

>> Stop twister and Naradabrokering.

>>Exactly in the same way run ./run_logitboostpara.sh to run LogitBoost.PL (code in LogitBoostPara)
>>Exactly in the same way run ./run_multboost.sh to run MultBoost (code in MultBoost).
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Determine Test error and standard deviation:
----------------------------------------------------------------------------------------------------------------------------------
1.In a single standalone linux machine create a folder name 'Evaluate' in home directory.

2.Copy the AdaBoostEvaluate.jar file into this folder along with weka.jar.

3.Go to home and execute (make shure shell script is executable):
	./eval_adaBoost.sh [num boost iterations] [num Folds] [arff f]
e.g.	./eval_adaBoost.sh 100 10 sonar.arff

4.Thus you have just run AdaBoost.

5.Similarly run ./eval_paraBoost.sh to run AdaBoost.PL (code in ParaBoostEvaluate).
6.Similarly run ./eval_logitBoost.sh to run LogitBoost (code in LogitBoostEvaluate).
7.Similarly run ./eval_logitBoostPara.sh to run LogitBoost.PL (code in LogitBoostParaEvaluate).
8.Similarly run ./eval_multBoost.sh to run MultBoost (code in MultBoostEvaluate).
----------------------------------------------------------------------------------------------------------------------------------



import java.text.DecimalFormat;

public class RunLogitBoostEvaluate {

    public static void main(String[] args) {
        if (args.length != 3) {
            String errorReport = "LogitBoostEvaluate: the Correct arguments are \n"
                            + "java RunLogitBoostEvaluate "
                            + "<num boost iterations> <num Folds> <arff file>";
            System.out.println(errorReport);
            System.exit(0);
        }
        int ni = Integer.parseInt(args[0]);
        int numFolds = Integer.parseInt(args[1]);
        String arfffname = args[2];

//        String arfffname = new String("/home/indranil/data/wineWhite.arff");//***************************
//        int ni = 100; //........................................................
//        int numFolds = 10;//****************************************************

        DecimalFormat FourPlaces = new DecimalFormat("#0.0000");

        arfffSplit afs = new arfffSplit(arfffname, numFolds);
        afs.getArffData();
            System.out.println("ARFF file loaded.");
        afs.split();
            System.out.println("Split done........ LogitBoost running.....");

        LogitBoost lb;
        double errorRate[] = new double[numFolds];
        StatCalc sc = new StatCalc();
        for(int i=0;i<numFolds;i++){
            System.out.println("Building Model for fold "+(i+1));
            lb = new LogitBoost(ni, afs.getDoubleTrainCV(i));
            lb.run();
//            lb.printOrgHyp();
//            double[][] sortedHyp = lb.getSortedHyps();
//            System.out.println("The sorted Hypothese in iterations (Class 2):");
//            for (int j=0; j<sortedHyp.length; j++){
//                for (int k=0; k<sortedHyp[0].length; k++){
//                    System.out.print(sortedHyp[j][k]+"\t");
//                }
//                System.out.println();
//            }
            System.out.println("Testing Model for fold "+(i+1));
            errorRate[i] = lb.evaluate(afs.getDoubleTestCV(i));
            sc.enter(errorRate[i]);
        }
        System.out.println(FourPlaces.format(sc.getMean())+" ("+FourPlaces.format(sc.getStandardDeviation())+")");
    }
}
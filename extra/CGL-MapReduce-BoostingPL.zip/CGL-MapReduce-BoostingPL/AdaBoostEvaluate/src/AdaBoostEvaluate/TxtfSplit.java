/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package AdaBoostEvaluate;

import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;
import weka.core.converters.CSVLoader;
import weka.core.converters.ArffLoader;
import weka.core.Instances;
import weka.core.Instance;
import weka.core.Utils;
import java.io.IOException;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;

public class TxtfSplit {

    private String txtfname;
    private int numSplit;
    private Instances data;
    private String filePrefix;
    private String filePath;
    private String header;
    private String dataString;
    private String arffString;
    private int numAtt;
    private int classIndex;

    public TxtfSplit(String f, int num){
        txtfname = f;
        numSplit = num;
        filePath = txtfname.substring(0, txtfname.lastIndexOf(".txt"));
    }

    public void getCsvData(){
        try{
            File file = new File(txtfname);
            filePrefix = file.getName();
            filePrefix = filePrefix.substring(0, filePrefix.lastIndexOf(".txt"));

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String inputLine = reader.readLine();// ignore numData
            if (inputLine == null)
                new IOException("First line = number of rows is null");
            inputLine = reader.readLine();
            if (inputLine == null)
                new IOException("Second line = size of the vector is null");
            String s = reader.readLine();
            s = s.concat("\n"+s+"\n");//duplicate the first line
            while ((inputLine = reader.readLine()) != null)
                s = s.concat(inputLine+"\n");
            s = s.replace(' ', ',');
            s = s.trim();

            file = new File(filePath+".csv");
            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            out.write(s);
            out.close();

            CSVLoader csv = new CSVLoader();
            csv.setSource(file);
            data = csv.getDataSet();
            file.delete();

            numAtt = data.numAttributes();

            // setting class attribute if the data format does not provide this information
            if (data.classIndex() == -1)
                data.setClassIndex(numAtt-1);

            classIndex = data.classIndex();
        } catch (Exception e){
            new IOException("Some IO problem here!!!!");
        }
    }

    public void setHeader(){
        header = new String("@relation "+filePrefix+"\n\n");
        int i;
        for (i=0; i<numAtt-1; i++)
            header = header.concat("@attribute a"+i+" numeric"+"\n");
        header = header.concat("@attribute a"+i+" {");

        double [] attVals = data.attributeToDoubleArray(classIndex);
        int n = data.numDistinctValues(classIndex);
        int [] sorted = Utils.sort(attVals);
        int prev = Integer.MIN_VALUE;
        int counter = n;
        for (i=0; i<sorted.length && counter>0 ; i++){
            Instance current = data.instance(sorted[i]);
            if ((i == 0) || (current.value(classIndex) > prev)) {
                prev = (int)current.value(classIndex);
                header = header.concat(prev+",");
                counter--;
            }
        }
        header= header.substring(0, header.lastIndexOf(','));
        header = header.concat("}\n\n@data\n");
    }

    public void setDataString(){
        dataString = data.toString();
        dataString = dataString.substring(dataString.lastIndexOf("@data")+6);
    }

    public void saveArff(){
        arffString = header.concat(dataString);
        arffString.trim();
        try{
            File file = new File(filePath+".arff");
            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            out.write(arffString);
            out.close();
        } catch (Exception e){
            new IOException("Some IO problem here!!!!");
        }
    }

    public void getArffData(){
        try{
            File file = new File(filePath+".arff");
            ArffLoader arff = new ArffLoader();
            arff.setSource(file);
            data = arff.getDataSet();
            // setting class attribute if the data format does not provide this information
            if (data.classIndex() == -1)
                data.setClassIndex(data.numAttributes() - 1);
            file.delete();
        } catch (Exception e){
            new IOException("Some IO problem here!!!!");
        }
    }

    public void split(){
        data.randomize(new Random(1));
        if (data.classAttribute().isNominal())
            data.stratify(numSplit);
    }
    
    public Instances gettestCV(int i){
        Instances split = data.testCV(numSplit, i);
        return split;
    }
    public Instances gettrainCV(int i){
        Instances split = data.trainCV(numSplit, i);
        return split;
    }    
    public void genSingleTwisterFile(){
        String s = new String(data.numInstances()+"\n"+data.numAttributes()+"\n");
        s = s.concat(dataString);
        s = s.replace(',', ' ');
        s = s.trim();

        try{
            File file = new File(filePath+".txt");
            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            out.write(s);
            out.close();
        } catch (Exception e){
            new IOException("Some IO problem here!!!!");
        }
    }
}
package AdaBoostEvaluate;

import java.text.DecimalFormat;

public class RunAdaBoostEvaluate {
    public static void main(String[] args) {
        if (args.length != 3) {
                String errorReport = "AdaBoostEvaluate: the Correct arguments are \n"
                                + "java AdaBoostEvaluate.RunAdaBoostEvaluate "
                                + "<num boost iterations> <num Folds> <text file>";
                System.out.println(errorReport);
                System.exit(0);
        }
        int ni = Integer.parseInt(args[0]);
        int numFolds = Integer.parseInt(args[1]);
        String arfffname = args[2];

//        String arfffname = "..//sonar.arff";//***************************
//        int ni = 100; //........................................................
//        int numFolds = 10;//****************************************************

        DecimalFormat FourPlaces = new DecimalFormat("#0.0000");

        arfffSplit afs = new arfffSplit(arfffname, numFolds);
        afs.getArffData();
            System.out.println("ARFF file loaded.");
        afs.split();
            System.out.println("Split done........ AdaBoost running.....");

        AdaBoost adb;
        double errorRate[] = new double[numFolds];
        StatCalc sc = new StatCalc();
        for(int i=0;i<numFolds;i++){
            System.out.println("Building Model for fold "+(i+1));
            adb = new AdaBoost(ni, afs.getDoubleTrainCV(i));
            adb.run();
            adb.printOrgHyp();
            double[][] sortedHyp = adb.getSortedHyps();
            System.out.println("The sorted Hypothese in iterations (Class 2):");
            for (int j=0; j<sortedHyp.length; j++){
                for (int k=0; k<sortedHyp[0].length; k++){
                    System.out.print(sortedHyp[j][k]+"\t");
                }
                System.out.println();
            }
            System.out.println("Testing Model for fold "+(i+1));
            errorRate[i] = adb.evaluate(afs.getDoubleTestCV(i));
            sc.enter(errorRate[i]);
        }
        System.out.println(FourPlaces.format(sc.getMean())+" ("+FourPlaces.format(sc.getStandardDeviation())+")");
    }
}
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package AdaBoostEvaluate;

/**
 *
 * @author indranil
 */

public class AdaBoost {
    private int numData;
    private int vecLen;
    private int classIndex;
    private double data[][];
    private double sdata[][];
    private int sindex[][];
    private double w[];
    private double weakHyp[][];
    private double sortedHyp[][];
    private int numIterations;
    private double delta = 0.000001;
    private double thisthresh = 0.0;
    private double thissign = 0.0;
    private double thiswterr = 0.0;
    private double bestwterr = 0.0;
    private double bestthresh = 0.0;
    private double bestsign = 0.0;
    private double bestaxis = 0.0;

    public AdaBoost(int ni, double d[][]){
        data = d;
        numIterations = ni;
        numData = d.length;
        vecLen = d[0].length;
        //find array index of class labels
        classIndex = vecLen-1;
        //initial uniform weight assignment
        w = new double[numData];
        double iw = 1.0/(double)numData;
        for(int i=0; i<numData; i++)
            w[i] = iw;
        //initialize weak hypothesis
        weakHyp = new double[numIterations][4];
        //sort data and index
        sdata = new double[classIndex][numData];
        sindex = new int[classIndex][numData];
        for(int i=0; i<classIndex; i++){
            for(int j=0; j<numData; j++){
                sdata[i][j] = data[j][i];
                sindex[i][j] = j;
            }
            quicksort(sdata[i], sindex[i]);
        }
        //we donot need to convert labels to 0,1; they are already so.
    }
    
    public void run(){
        int i,j;
        for ( i=0; i<numIterations; i++ ){
            decisionStump();
            double epsMinus = bestwterr;
            double epsPlus = 1.0 - epsMinus;
            epsMinus += delta;
            epsPlus += delta;
            for ( j=0; j<numData; j++ ) {
                double val = data[j][(int)bestaxis];
                double pred = (val<bestthresh)?bestsign:-bestsign;
                double y = data[j][classIndex];
                w[j] = (((pred==+1.0) && (y==1.0))||((pred==-1.0) && (y==0.0)))? w[j]/(2*epsPlus):w[j]/(2*epsMinus);
            }
            weakHyp[i][0] = bestaxis;
            weakHyp[i][1] = bestthresh;
            weakHyp[i][2] = bestsign;
            weakHyp[i][3] = (Math.log(epsPlus/epsMinus))/2.0;
        }
        //this.printOrgHyp();
    }
    public double evaluate(double[][] test){
        int numPoint = test.length;
        int correct = 0;
        for(int i=0; i<numPoint; i++){
            double sum = 0.0;
            for(int j=0; j<weakHyp.length; j++){
                int axis = (int)weakHyp[j][0];
                double thresh = weakHyp[j][1];
                double sign = weakHyp[j][2];
                double alpha = weakHyp[j][3];
                double val = test[i][axis];
                double pred = (val<thresh)?sign:-sign;
                sum += pred*alpha;
            }
            double y = test[i][classIndex];
            
            if (((sum > 0.0) && (y == 1.0)) || ((sum < 0.0) && (y == 0.0)))
                correct++;
        }
        return (((double)(numPoint-correct))/((double)numPoint));
    }
    public void printOrgHyp(){
        System.out.println("The actual Hypothese in iterations:");
        for (int i=0; i<numIterations; i++){
            for (int j=0; j<weakHyp[0].length; j++){
                System.out.print(weakHyp[i][j]+"\t");
            }
            System.out.println();
        }
    }
    public double[][] getSortedHyps(){
        double err[] = new double[weakHyp.length];
        for (int i=0; i<err.length; i++)
            err[i] = weakHyp[i][3];
        int index[] = new int[err.length];
        for (int i=0; i<index.length; i++)
            index[i] = i;
        quicksort(err, index);
        sortedHyp = new double[weakHyp.length][weakHyp[0].length];
        for (int i=0; i<sortedHyp.length; i++){
            int pos = index[i];
            for (int j=0; j<sortedHyp[0].length; j++)
                sortedHyp[i][j] = weakHyp[pos][j];
        }
        return sortedHyp;
    }
    public void decisionStump(){
        //find total weight
        double totwt = 0.0;
        for (int i=0; i<numData; i++)
            totwt += w[i];
        //find total weights of label ones'
        double oneswt = 0.0;
        for (int i=0; i<numData; i++)
            if (data[i][classIndex] != 0)
                oneswt += w[i];
        bestwterr = totwt + 1.0;

        for (int i=0; i<classIndex; i++){
            optthresh(i, totwt, oneswt);
            if (thiswterr < bestwterr) {
                bestthresh = thisthresh;
                bestsign = thissign;
                bestwterr = thiswterr;
                bestaxis = i;
            }
        }
    }
    public void optthresh(int att, double totwt, double oneswt){
        double max = sdata[att][numData-1];
        thisthresh = (max>0)? 2*max : 0.0;
        double zeroswt = totwt-oneswt;
        thissign = (zeroswt < oneswt) ? +1.0 : -1.0;
        thiswterr = Math.min( zeroswt,oneswt);
        double leftoneswt = 0.0;
        double leftzeroswt=0.0;
        for (int i=0; i<numData-1; i++){
           if (data[sindex[att][i]][classIndex]!= 0.0)/////////////////
              leftoneswt += w[sindex[att][i]];
           else
              leftzeroswt += w[sindex[att][i]];
           if (sdata[att][i+1] != sdata[att][i]) {
              if ( (leftoneswt + totwt - oneswt - leftzeroswt) < thiswterr ) {
                 thiswterr = leftoneswt + totwt - oneswt - leftzeroswt;
                 thissign = -1.0;
                 thisthresh = (sdata[att][i] + sdata[att][i+1])/2;
              }
              if ( (leftzeroswt + oneswt - leftoneswt) < thiswterr ) {
                 thiswterr = leftzeroswt + oneswt - leftoneswt;
                 thissign = +1.0;
                 thisthresh = (sdata[att][i] + sdata[att][i+1])/2;
              }
           }
        }
    }
    public static void quicksort(double[] main, int[] index) {
        quicksort(main, index, 0, index.length - 1);
    }
    // quicksort a[left] to a[right]
    public static void quicksort(double[] a, int[] index, int left, int right) {
        if (right <= left) return;
        int i = partition(a, index, left, right);
        quicksort(a, index, left, i-1);
        quicksort(a, index, i+1, right);
    }
    // partition a[left] to a[right], assumes left < right
    private static int partition(double[] a, int[] index, int left, int right) {
        int i = left - 1;
        int j = right;
        while (true) {
            while (less(a[++i], a[right]))      // find item on left to swap
                ;                               // a[right] acts as sentinel
            while (less(a[right], a[--j]))      // find item on right to swap
                if (j == left) break;           // don't go out-of-bounds
            if (i >= j) break;                  // check if pointers cross
            exch(a, index, i, j);               // swap two elements into place
        }
        exch(a, index, i, right);               // swap with partition element
        return i;
    }
    // is x < y ?
    private static boolean less(double x, double y) {
        return (x < y);
    }
    // exchange a[i] and a[j]
    private static void exch(double[] a, int[] index, int i, int j) {
        double swap = a[i];
        a[i] = a[j];
        a[j] = swap;
        int b = index[i];
        index[i] = index[j];
        index[j] = b;
    }
}
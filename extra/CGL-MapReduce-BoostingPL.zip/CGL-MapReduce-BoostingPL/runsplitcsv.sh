if [ $# -ne 2 ]; then
    echo Usage: [number of split][csv file]
    exit -1
fi


export SPLITCSV_HOME=${HOME}/splitcsv

cp=$SPLITCSV_HOME:.

for i in ${SPLITCSV_HOME}/*.jar;
  do cp=$i:${cp}
done

java -Xmx2000m -Xms1000m -XX:SurvivorRatio=10 -classpath $cp csvtosplitarff.MakeSplit $1 $2

import java.text.DecimalFormat;
import weka.core.Instances;
import java.util.Random;

public class RunLogitBoostParaEvaluate {

    public static void main(String[] args) {
        if (args.length != 4) {
                String errorReport = "ParaLogitBoostEvaluate: the Correct arguments are \n"
                                + "java RunParaLogitBoostEvaluate "
                                + "<num boost iterations> <num Folds> <text file> <num workers>";
                System.out.println(errorReport);
                System.exit(0);
        }
        int ni = Integer.parseInt(args[0]);
        int numFolds = Integer.parseInt(args[1]);
        String arfffname = args[2];
        int numAgents = Integer.parseInt(args[3]);

//        String arfffname = new String("/home/indranil/data/g1.arff");//***************************
//        int ni = 100; //........................................................
//        int numFolds = 10;//****************************************************
//        int numAgents = 20;

        DecimalFormat FourPlaces = new DecimalFormat("#0.0000");

        arfffSplit afs = new arfffSplit(arfffname, numFolds);
        afs.getArffData();
            System.out.println("ARFF file loaded.");
        afs.split();
            System.out.println("Split done........ ParaLogitBoost running.....");

        double errorRate[] = new double[numFolds];
        StatCalc sc = new StatCalc();
        Instances trainFold, trainAgent;
        for(int i=0;i<numFolds;i++){
            System.out.println("Building Model for fold "+(i+1));
            trainFold = afs.getArffTrainCV(i);
            trainFold.randomize(new Random(1));
            if (trainFold.classAttribute().isNominal())
                trainFold.stratify(numAgents);

            LogitBoost lb[] = new LogitBoost[numAgents];
            double hyps[][][] = new double[numAgents][ni][5];
            for (int j=0; j<numAgents; j++){
                trainAgent = trainFold.testCV(numAgents, j);
                lb[j] = new LogitBoost(ni, instoDouble(trainAgent));
                lb[j].run();
                hyps[j] = lb[j].getSortedHyps();
            }

            System.out.println("Testing Model for fold "+(i+1));
            double testData[][] = instoDouble(afs.getArffTestCV(i));
            int numTestData = testData.length;
            int classIndex = testData[0].length-1;
            int correct = 0;
            for(int j=0; j<numTestData; j++){                
                double sum2 = 0.0;
                for(int k=0; k<ni; k++){
                    double sum1 = 0.0;
                    for(int l=0; l<numAgents; l++){
                        double val = testData[j][(int)hyps[l][k][0]];
                        double pred = (val<=hyps[l][k][1])?hyps[l][k][2]:hyps[l][k][3];
                        sum1 += pred;
                    }
                    sum1 = sum1/((double)numAgents);
                    sum2 += sum1;
                }
                double y = testData[j][classIndex];
                if (((sum2 > 0.0) && (y == 1.0)) || ((sum2 < 0.0) && (y == 0.0)))
                    correct++;
            }
            errorRate[i] = (((double)(numTestData-correct))/((double)numTestData));
            sc.enter(errorRate[i]);
        }
        System.out.println(FourPlaces.format(sc.getMean())+" ("
                +FourPlaces.format(sc.getStandardDeviation())+")");
    }
    public static double[][] instoDouble(Instances ins){
        int numIns = ins.numInstances();
        int numAtt = ins.numAttributes();
        double splitData[][] = new double[numIns][numAtt];
        double tmp[] = new double[numIns];
        for(int k=0; k<splitData[0].length; k++){
            tmp = ins.attributeToDoubleArray(k);
            for(int l=0; l<splitData.length; l++){
                splitData[l][k] = tmp[l];
            }
        }
        return splitData;
    }
}
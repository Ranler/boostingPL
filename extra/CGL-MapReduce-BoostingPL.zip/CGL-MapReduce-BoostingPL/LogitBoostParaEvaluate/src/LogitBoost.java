
public class LogitBoost {
    private int numData;
    private int vecLen;
    private int classIndex;
    private double[][] data;
    private double[] w;
    private double[] probs;
    private double[] trainFs;
    private double[] z;
    private double weakHyp[][];
    private double sortedHyp[][];
    private int numIterations;
    private int numDecision = 2;
    private double[] sdata;
    private int[] sindex;

    protected static final double Z_MAX = 3;    
       
    private double[] m_Distribution;
    private double m_SplitPoint;
    private int m_AttIndex;
    private double[] Distribution;
    private double SplitPoint;

    public LogitBoost(int ni, double[][] d){
        data = d;
        numIterations = ni;
        numData = data.length;
        vecLen = data[0].length;
        //find array index of class labels
        classIndex = vecLen-1;
        //initial uniform probability estimetes
        w = new double[numData];
        z = new double[numData];
        probs = new double[numData];
        trainFs = new double [numData];
        for(int i=0; i<numData; i++){
            probs[i] = 0.5;
        }
        //initialize weak hypothesis
        weakHyp = new double[numIterations][5];
        //we donot need to convert labels to 0,1; they are already so.
    }
    
    public void run(){
        // Perform iterations       
        double origSumOfWeights = 1.0;
        for (int j = 0; j < numIterations; j++) {            
            for (int i = 0; i < numData; i++) {
                // Compute response and weight
                double p = probs[i];
                double zVal, actual = data[i][classIndex];
                if (actual == 1 ) {
                  zVal = 1.0 / p;
                  if (zVal > Z_MAX) { // threshold
                    zVal = Z_MAX;
                  }
                } else {
                  zVal = -1.0 / (1.0 - p);
                  if (zVal < -Z_MAX) { // threshold
                    zVal = -Z_MAX;
                  }
                }
                z[i] = zVal;
                w[i] = (actual - p) / zVal;
            }
            // Scale the weights
            double sumOfWeights = 0.0;
            for (int i = 0; i < numData; i++) {
                sumOfWeights += w[i];
            }
            double scalingFactor = (double)origSumOfWeights / sumOfWeights;
            for (int i = 0; i < numData; i++) {
                w[i] *= scalingFactor;
            }

            // Build the classifier
            double bestVal = Double.MAX_VALUE, currVal;
            m_Distribution = new double[numDecision];
            Distribution = new double[numDecision];
            double totalSum = 0.0;
            double totalSumOfWeights = 0.0;
            double squareSum = 0.0;
            double cv, wt; 
            for (int i = 0; i < numData; i++) {                
                cv = z[i];
                wt = w[i];
                totalSumOfWeights += wt;
                totalSum += cv * wt;
                squareSum += cv * cv * wt;
            }           
            // For each attribute except class
            for (int i = 0; i < classIndex; i++) {                                
                // Compute value of criterion for best split on attribute
                currVal = findSplitNumericNumeric(i, totalSum, totalSumOfWeights, squareSum);
                if (currVal < bestVal) {
                    bestVal = currVal;
                    m_AttIndex = i;
                    m_SplitPoint = SplitPoint;
                    for (int k = 0; k < numDecision; k++) {
                        m_Distribution[k] = Distribution[k];
                    }
                }
            }
            // Set attribute, split point and distribution.            
            weakHyp[j][0] = m_AttIndex;
            weakHyp[j][1] = m_SplitPoint;
            weakHyp[j][2] = m_Distribution[0];
            weakHyp[j][3] = m_Distribution[1];
            weakHyp[j][4] = evalSingleHyp();

            // Evaluate / increment trainFs from the classifier
            for (int i = 0; i < numData; i++) {
                double val = data[i][(int)weakHyp[j][0]];
                double pred = (val <= weakHyp[j][1])?weakHyp[j][2]:weakHyp[j][3];
                trainFs[i] += pred/2.0;
                probs[i] = 1.0/(1.0+Math.exp(-2*trainFs[i]));
            }
        }
    }
    private double findSplitNumericNumeric(int index, double totalSum, double totalSumOfWeights, double squareSum){
        double bestVal = Double.MAX_VALUE, currVal;
        double[] sumsSquares = new double[numDecision];
        double[] sumOfWeights = new double[numDecision];
        double[] curr_Distribution = new double[numDecision];
        curr_Distribution[1] = totalSum;
        sumsSquares[1] = squareSum;
        sumOfWeights[1] = totalSumOfWeights;
        // Check if the total weight is zero
        if (totalSumOfWeights <= 0) {
            return bestVal;
        }
        //sort attribute and index
        sdata = new double[numData];
        sindex = new int[numData];
        for(int i=0; i<numData; i++){
            sdata[i] = data[i][index];
            sindex[i] = i;
        }
        quicksort(sdata, sindex);
        // Make split counts for each possible split and evaluate
        for (int i = 0; i < numData - 1; i++) {
            int pos = sindex[i];
            double cv = z[pos];
            double wt = w[pos];
            curr_Distribution[0] += cv * wt;
            sumsSquares[0] += cv * cv * wt;
            sumOfWeights[0] += wt;
            curr_Distribution[1] -= cv * wt;
            sumsSquares[1] -= cv * cv * wt;
            sumOfWeights[1] -= wt;
            if (sdata[i] < sdata[i+1]) {                
                currVal = variance(curr_Distribution, sumsSquares, sumOfWeights);
                if (currVal < bestVal) {
                    SplitPoint = (sdata[i] + sdata[i+1]) / 2.0;
                    bestVal = currVal;
                    for (int j = 0; j < numDecision; j++) {
                        if (sumOfWeights[j] > 0) {
                            Distribution[j] = curr_Distribution[j] / sumOfWeights[j];
                        } else {
                            Distribution[j] = totalSum / totalSumOfWeights;
                        }
                    }
                }
            }
        }
        return bestVal;
    }
    public void printOrgHyp(){
        System.out.println("The actual Hypothese in iterations:");
        for (int i=0; i<numIterations; i++){            
            for (int j=0; j<weakHyp[0].length; j++){
                System.out.print(weakHyp[i][j]+"\t");
            }
            System.out.println();
        }
    }
    public double evalSingleHyp(){
        int correct = 0;
        for(int i=0; i<numData; i++){            
            double val = data[i][m_AttIndex];
            double pred = (val <= m_SplitPoint)?m_Distribution[0]:m_Distribution[1];
            double y = data[i][classIndex];
            if (((pred > 0.0) && (y == 1.0)) || ((pred < 0.0) && (y == 0.0)))
                correct++;
        }
        return (((double)(numData-correct))/((double)numData));
    }
    public double evaluate(double[][] testFold){
        int numTestData = testFold.length;
        int correct = 0;
        for(int i=0; i<numTestData; i++){
            double sum = 0.0;
            for(int j=0; j<numIterations; j++){
                double val = testFold[i][(int)weakHyp[j][0]];
                double pred = (val <= weakHyp[j][1])?weakHyp[j][2]:weakHyp[j][3];
                sum += pred;
            }
            double y = testFold[i][classIndex];
            if (((sum > 0.0) && (y == 1.0)) || ((sum < 0.0) && (y == 0.0)))
                correct++;
        }
        return (((double)(numTestData-correct))/((double)numTestData));
    }
    /**
    * Computes variance for subsets.
    */
    private double variance(double[] s,double[] sS,double[] sumOfWeights) {
        double var = 0;
        for (int i = 0; i < s.length; i++) {
            if (sumOfWeights[i] > 0) {
                var += sS[i] - ((s[i] * s[i]) / (double) sumOfWeights[i]);
            }
        }
        return var;
    }
    public double[][] getSortedHyps(){
        double err[] = new double[weakHyp.length];
        for (int i=0; i<err.length; i++)
            err[i] = weakHyp[i][4];
        int index[] = new int[err.length];
        for (int i=0; i<index.length; i++)
            index[i] = i;
        quicksort(err, index);
        sortedHyp = new double[weakHyp.length][weakHyp[0].length];
        for (int i=0; i<sortedHyp.length; i++){
            int pos = index[i];
            for (int j=0; j<sortedHyp[0].length; j++)
                sortedHyp[i][j] = weakHyp[pos][j];
        }
        return sortedHyp;
    }
    public static void quicksort(double[] main, int[] index) {
        quicksort(main, index, 0, index.length - 1);
    }
    // quicksort a[left] to a[right]
    public static void quicksort(double[] a, int[] index, int left, int right) {
        if (right <= left) return;
        int i = partition(a, index, left, right);
        quicksort(a, index, left, i-1);
        quicksort(a, index, i+1, right);
    }
    // partition a[left] to a[right], assumes left < right
    private static int partition(double[] a, int[] index, int left, int right) {
        int i = left - 1;
        int j = right;
        while (true) {
            while (less(a[++i], a[right]))      // find item on left to swap
                ;                               // a[right] acts as sentinel
            while (less(a[right], a[--j]))      // find item on right to swap
                if (j == left) break;           // don't go out-of-bounds
            if (i >= j) break;                  // check if pointers cross
            exch(a, index, i, j);               // swap two elements into place
        }
        exch(a, index, i, right);               // swap with partition element
        return i;
    }
    // is x < y ?
    private static boolean less(double x, double y) {
        return (x < y);
    }
    // exchange a[i] and a[j]
    private static void exch(double[] a, int[] index, int i, int j) {
        double swap = a[i];
        a[i] = a[j];
        a[j] = swap;
        int b = index[i];
        index[i] = index[j];
        index[j] = b;
    }
}
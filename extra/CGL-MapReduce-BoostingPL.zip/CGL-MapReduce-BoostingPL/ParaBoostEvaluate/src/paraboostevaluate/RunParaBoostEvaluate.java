package paraboostevaluate;

import java.text.DecimalFormat;
import weka.core.Instances;
import java.util.Random;

public class RunParaBoostEvaluate {
    public static void main(String[] args) {
        if (args.length != 4) {
                String errorReport = "ParaBoostEvaluate: the Correct arguments are \n"
                                + "java paraboostevaluate.RunParaBoostEvaluate "
                                + "<num boost iterations> <num Folds> <arff file> <num workers>";
                System.out.println(errorReport);
                System.exit(0);
        }
        int ni = Integer.parseInt(args[0]);
        int numFolds = Integer.parseInt(args[1]);
        String arfffname = args[2];
        int numAgents = Integer.parseInt(args[3]);


//        String arfffname = new String("/home/indranil/data/sonar.arff");//***************************
//        int ni = 100; //........................................................
//        int numFolds = 10;//****************************************************
//        int numAgents = 10;//****************************************************

        DecimalFormat FourPlaces = new DecimalFormat("#0.0000");

        arfffSplit afs = new arfffSplit(arfffname, numFolds);
        afs.getArffData();
            System.out.println("ARFF file loaded.");
        afs.split();
            System.out.println("Split done........ ParaBoost running.....");


        double errorRate[] = new double[numFolds];
        StatCalc sc = new StatCalc();
        Instances trainFold, trainAgent;
        for(int i=0;i<numFolds;i++){
            System.out.println("Building Model for fold "+(i+1));
            trainFold = afs.getArffTrainCV(i);
            trainFold.randomize(new Random(1));
            if (trainFold.classAttribute().isNominal())
                trainFold.stratify(numAgents);

            AdaBoost adb[] = new AdaBoost[numAgents];
            double hyps[][][] = new double[numAgents][ni][4];
            for (int j=0; j<numAgents; j++){
                trainAgent = trainFold.testCV(numAgents, j);
                adb[j] = new AdaBoost(ni, instoDouble(trainAgent));
                adb[j].run();
                hyps[j] = adb[j].getSortedHyps();
            }

            double alpha[] = new double[ni];
            for(int j=0; j<ni; j++){
                double sum = 0.0;
                for(int k=0; k<numAgents; k++){
                    sum += hyps[k][j][3];
                }
                alpha[j] = sum/numAgents;
            }

            System.out.println("Testing Model for fold "+(i+1));
            double testData[][] = instoDouble(afs.getArffTestCV(i));
            int numData = testData.length;
            int classIndex = testData[0].length-1;
            int correct = 0;
            for(int j=0; j<numData; j++){
                double sum2 = 0.0;
                for(int k=0; k<ni; k++){
                    double sum1 = 0.0;
                    for(int l=0; l<numAgents; l++){
                        int axis = (int)hyps[l][k][0];
                        double thresh = hyps[l][k][1];
                        double sign = hyps[l][k][2];
                        double val = testData[j][axis];
                        double pred = (val<thresh)?sign:-sign;
                        sum1 += pred;
                    }
                    if (sum1 > 0.0)
                        sum2 += alpha[k];
                    else if (sum1 < 0.0)
                        sum2 += -alpha[k];
                }
                double y = testData[j][classIndex];
                if (((sum2 > 0.0) && (y == 1.0)) || ((sum2 < 0.0) && (y == 0.0)))
                    correct++;
            }
            errorRate[i] = (((double)(numData-correct))/((double)numData));
            sc.enter(errorRate[i]);
        }
        System.out.println(FourPlaces.format(sc.getMean())+" ("
                +FourPlaces.format(sc.getStandardDeviation())+")");
    }
    public static double[][] instoDouble(Instances ins){
        int numIns = ins.numInstances();
        int numAtt = ins.numAttributes();
        double splitData[][] = new double[numIns][numAtt];
        double tmp[] = new double[numIns];
        for(int k=0; k<splitData[0].length; k++){
            tmp = ins.attributeToDoubleArray(k);
            for(int l=0; l<splitData.length; l++){
                splitData[l][k] = tmp[l];
            }
        }
        return splitData;
    }
}
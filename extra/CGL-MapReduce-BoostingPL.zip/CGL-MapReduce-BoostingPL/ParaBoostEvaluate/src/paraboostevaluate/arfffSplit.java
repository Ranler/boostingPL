package paraboostevaluate;


import java.io.File;
import weka.core.converters.ArffLoader;
import weka.core.Instances;
import java.io.IOException;
import java.util.Random;

public class arfffSplit {

    private String arfffname;
    private int numSplit;
    private Instances data;
    private int numAtt;

    public arfffSplit(String f, int num){
        arfffname = f;
        numSplit = num;      
    }

    public void getArffData(){
        try{
            File file = new File(arfffname);
            ArffLoader arff = new ArffLoader();
            arff.setSource(file);
            data = arff.getDataSet();
            numAtt = data.numAttributes();
            // setting class attribute if the data format does not provide this information
            if (data.classIndex() == -1)
                data.setClassIndex(data.numAttributes() - 1);
        } catch (Exception e){
            new IOException("Some IO problem here!!!!");
        }
    }

    public void split(){
        data.randomize(new Random(1));
        if (data.classAttribute().isNominal())
            data.stratify(numSplit);
    }
    public double[][] getDoubleTestCV(int i){
        Instances split = data.testCV(numSplit, i);
        int numIns = split.numInstances();
        double splitData[][] = new double[numIns][numAtt];
        double tmp[] = new double[numIns];

        for(int j=0; j<splitData[0].length; j++){
            tmp = split.attributeToDoubleArray(j);
            for(int k=0; k<splitData.length; k++){
                splitData[k][j] = tmp[k];
            }
        }
        return splitData;
    }
    public double[][] getDoubleTrainCV(int i){
        Instances split = data.trainCV(numSplit, i);
        int numIns = split.numInstances();
        double splitData[][] = new double[numIns][numAtt];
        double tmp[] = new double[numIns];

        for(int j=0; j<splitData[0].length; j++){
            tmp = split.attributeToDoubleArray(j);
            for(int k=0; k<splitData.length; k++){
                splitData[k][j] = tmp[k];
            }
        }
        return splitData;
    }
    public double[][] getDoubleFullData(){
        int numIns = data.numInstances();
        double splitData[][] = new double[numIns][numAtt];
        double tmp[] = new double[numIns];

        for(int j=0; j<splitData[0].length; j++){
            tmp = data.attributeToDoubleArray(j);
            for(int k=0; k<splitData.length; k++){
                splitData[k][j] = tmp[k];
            }
        }
        return splitData;
    }
    public Instances getArffTestCV(int i){
        return data.testCV(numSplit, i);
    }
    public Instances getArffTrainCV(int i){
        return data.trainCV(numSplit, i);
    }
    public Instances getArffFullData(){
        return data;
    }
}
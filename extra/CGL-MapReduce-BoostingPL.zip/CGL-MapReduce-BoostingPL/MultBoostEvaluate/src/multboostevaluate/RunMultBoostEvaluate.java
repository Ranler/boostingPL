/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package multboostevaluate;

import java.text.DecimalFormat;
import weka.core.Instances;
import java.util.Random;

public class RunMultBoostEvaluate {
    public static void main(String[] args) {
        if (args.length != 4) {
                String errorReport = "MultBoostEvaluate: the Correct arguments are \n"
                                + "java multboostevaluate.RunMultBoostEvaluate "
                                + "<num boost iterations> <num Folds> <text file> <num workers>";
                System.out.println(errorReport);
                System.exit(0);
        }
        int ni = Integer.parseInt(args[0]);
        int numFolds = Integer.parseInt(args[1]);
        String arfffname = args[2];
        int numAgents = Integer.parseInt(args[3]);

//        String arfffname = new String("/home/indranil/data/sonar.arff");//***************************
//        int ni = 100; //........................................................
//        int numFolds = 10;//****************************************************
//        int numAgents = 10;//****************************************************

        DecimalFormat FourPlaces = new DecimalFormat("#0.0000");

        double delta = 0.000001;

        arfffSplit afs = new arfffSplit(arfffname, numFolds);
        afs.getArffData();
            System.out.println("ARFF file loaded.");
        afs.split();
            System.out.println("Split done........ MultBoost running.....");

        double errorRate[] = new double[numFolds];
        StatCalc sc = new StatCalc();
        Instances trainFold, trainAgent;        
        for(int i=0;i<numFolds;i++){
            System.out.println("Building Model for fold "+(i+1));
            trainFold = afs.getArffTrainCV(i);
            trainFold.randomize(new Random(1));
            if (trainFold.classAttribute().isNominal())
                trainFold.stratify(numAgents);
            MultBoost mlb[] = new MultBoost[numAgents];
            
            for (int j=0; j<mlb.length; j++){
                trainAgent = trainFold.testCV(numAgents, j);
                mlb[j] = new MultBoost(numAgents, instoDouble(trainAgent));
            }
            double weakHyp[][][] = new double[ni][numAgents][3];
            double alpha[] = new double[ni];
            double eps[][] = new double[numAgents][2];
            double epsPlus = 0.0;
            double epsMinus = 0.0;
            double epsZero = 0.0;
            for (int j=0; j<ni; j++){
                for (int k=0; k<numAgents; k++)
                    weakHyp[j][k] = mlb[k].runSingleIteration(j, epsPlus, epsMinus, epsZero);
                for (int k=0; k<numAgents; k++)
                    eps[k] = mlb[k].evaluateCompositeHyp(weakHyp[j]);
                epsPlus = 0.0;
                epsMinus = 0.0;
                for (int k=0; k<numAgents; k++){
                    epsPlus += eps[k][0];
                    epsMinus += eps[k][1];
                }
                epsZero = 1 - epsPlus - epsMinus;
                epsPlus += delta;
                epsMinus += delta;
                alpha[j] = (Math.log(epsPlus/epsMinus))/2.0;
            }
            System.out.println("Testing Model for fold "+(i+1));
            double testData[][] = instoDouble(afs.getArffTestCV(i));
            int numData = testData.length;
            int correct = 0;
            for(int j=0; j<numData; j++){
                double sum2 = 0.0;
                for(int k=0; k<ni; k++){
                    double sum1 = 0.0;
                    for(int l=0; l<numAgents; l++){
                        int axis = (int)weakHyp[k][l][0];
                        double thresh = weakHyp[k][l][1];
                        double sign = weakHyp[k][l][2];
                        double val = testData[j][axis];
                        double pred = (val<thresh)?sign:-sign;
                        sum1 += pred;
                    }
                    if (sum1 > 0.0)
                        sum2 += alpha[k];
                    else if (sum1 < 0.0)
                        sum2 += -alpha[k];
                }
                double y = testData[j][testData[0].length-1];
                if (((sum2 > 0.0) && (y == 1.0)) || ((sum2 < 0.0) && (y == 0.0)))
                    correct++;
            }
            errorRate[i] = (((double)(numData-correct))/((double)numData));
            sc.enter(errorRate[i]);
        }
        System.out.println(FourPlaces.format(sc.getMean())+" ("
                +FourPlaces.format(sc.getStandardDeviation())+")");
    }
    public static double[][] instoDouble(Instances ins){
        int numIns = ins.numInstances();
        int numAtt = ins.numAttributes();
        double splitData[][] = new double[numIns][numAtt];
        double tmp[] = new double[numIns];
        for(int k=0; k<splitData[0].length; k++){
            tmp = ins.attributeToDoubleArray(k);
            for(int l=0; l<splitData.length; l++){
                splitData[l][k] = tmp[l];
            }
        }
        return splitData;
    }
}
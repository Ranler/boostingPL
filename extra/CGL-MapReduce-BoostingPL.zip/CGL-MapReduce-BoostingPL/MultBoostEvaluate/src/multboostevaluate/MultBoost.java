package multboostevaluate;

/**
 *
 * @author navrodsky
 */

public class MultBoost {
    private int numAgents;
    private int numData;
    private int vecLen;
    private int classIndex;
    private double data[][];
    private double sdata[][];
    private int sindex[][];
    private double w[];
    private int flag[];
    private double thisthresh = 0.0;
    private double thissign = 0.0;
    private double thiswterr = 0.0;
    private double bestwterr = 0.0;
    private double bestthresh = 0.0;
    private double bestsign = 0.0;
    private double bestaxis = 0.0;

    public MultBoost(int na, double d[][]){
        data = d;
        numAgents = na;
        numData = d.length;
        vecLen = d[0].length;
        //find array index of class labels
        classIndex = vecLen-1;
        //initial uniform weight assignment
        w = new double[numData];
        double iw = 1.0/(double)(numData*numAgents);
        for(int i=0; i<numData; i++)
            w[i] = iw;
        //initialize flag
        flag = new int[numData];
        //sort data and index
        sdata = new double[classIndex][numData];
        sindex = new int[classIndex][numData];
        for(int i=0; i<classIndex; i++){
            for(int j=0; j<numData; j++){
                sdata[i][j] = data[j][i];
                sindex[i][j] = j;
            }
            quicksort(sdata[i], sindex[i]);
        }
        //we donot need to convert labels to 0,1; they are already so.
    }

    public double[] runSingleIteration(int i, double eps1, double eps2, double eps3){
        if (i!=0)
            updateW(eps1, eps2, eps3);
        decisionStump();
        double hyp[] = {bestaxis, bestthresh, bestsign};
        return hyp;
    }

    public double[] evaluateCompositeHyp(double[][] weakHyp){
        double eps[] = new double[2];
        for (int i=0; i<eps.length; i++)
            eps[i] = 0.0;
        for(int i=0; i<numData; i++){
            double sum = 0.0;
            for(int j=0; j<weakHyp.length; j++){
                int axis = (int)weakHyp[j][0];
                double thresh = weakHyp[j][1];
                double sign = weakHyp[j][2];
                double val = data[i][axis];
                double pred = (val<thresh)?sign:-sign;
                sum += pred;
            }
            double y = data[i][classIndex];
            if (sum > 0.0){
                if (y == 1.0){
                    eps[0] += w[i];
                    flag[i] = 1;
                }
                else{
                    eps[1] += w[i];
                    flag[i] = 2;
                }
            }
            else if (sum < 0.0) {
                if (y == 0.0){
                    eps[0] += w[i];
                    flag[i] = 1;
                }
                else{
                    eps[1] += w[i];
                    flag[i] = 2;
                }
            }
            else
                flag[i] = 0;
        }
        return eps;
    }

    public void updateW(double eps1, double eps2, double eps3){
        double epsPlus = eps1;
        double epsMinus = eps2;
        double epsZero = eps3;
        for (int j=0; j<numData; j++){
            if (flag[j] == 1)
                w[j] /= ((2.0*epsPlus)+(epsZero*Math.sqrt(epsPlus/epsMinus)));
            else if (flag[j] == 2)
                w[j] /= ((2.0*epsMinus)+(epsZero*Math.sqrt(epsMinus/epsPlus)));
            else
                w[j] /= (epsZero+(2*Math.sqrt(epsPlus*epsMinus)));
        }
    }

    public void decisionStump(){
        //find total weight
        double totwt = 0.0;
        for (int i=0; i<numData; i++)
            totwt += w[i];
        //find total weights of label ones'
        double oneswt = 0.0;
        for (int i=0; i<numData; i++)
            if (data[i][classIndex] != 0)
                oneswt += w[i];
        bestwterr = totwt + 1.0;

        for (int i=0; i<classIndex; i++){
            optthresh(i, totwt, oneswt);
            if (thiswterr < bestwterr) {
                bestthresh = thisthresh;
                bestsign = thissign;
                bestwterr = thiswterr;
                bestaxis = i;
            }
        }
    }
    public void optthresh(int att, double totwt, double oneswt){
        double max = sdata[att][numData-1];
        thisthresh = (max>0)? 2*max : 0.0;
        double zeroswt = totwt-oneswt;
        thissign = (zeroswt < oneswt) ? +1.0 : -1.0;
        thiswterr = Math.min( zeroswt,oneswt);
        double leftoneswt = 0.0;
        double leftzeroswt=0.0;
        for (int i=0; i<numData-1; i++){
           if (data[sindex[att][i]][classIndex]!= 0.0)/////////////////
              leftoneswt += w[sindex[att][i]];
           else
              leftzeroswt += w[sindex[att][i]];
           if (sdata[att][i+1] != sdata[att][i]) {
              if ( (leftoneswt + totwt - oneswt - leftzeroswt) < thiswterr ) {
                 thiswterr = leftoneswt + totwt - oneswt - leftzeroswt;
                 thissign = -1.0;
                 thisthresh = (sdata[att][i] + sdata[att][i+1])/2;
              }
              if ( (leftzeroswt + oneswt - leftoneswt) < thiswterr ) {
                 thiswterr = leftzeroswt + oneswt - leftoneswt;
                 thissign = +1.0;
                 thisthresh = (sdata[att][i] + sdata[att][i+1])/2;
              }
           }
        }
    }
    public static void quicksort(double[] main, int[] index) {
        quicksort(main, index, 0, index.length - 1);
    }
    // quicksort a[left] to a[right]
    public static void quicksort(double[] a, int[] index, int left, int right) {
        if (right <= left) return;
        int i = partition(a, index, left, right);
        quicksort(a, index, left, i-1);
        quicksort(a, index, i+1, right);
    }
    // partition a[left] to a[right], assumes left < right
    private static int partition(double[] a, int[] index, int left, int right) {
        int i = left - 1;
        int j = right;
        while (true) {
            while (less(a[++i], a[right]))      // find item on left to swap
                ;                               // a[right] acts as sentinel
            while (less(a[right], a[--j]))      // find item on right to swap
                if (j == left) break;           // don't go out-of-bounds
            if (i >= j) break;                  // check if pointers cross
            exch(a, index, i, j);               // swap two elements into place
        }
        exch(a, index, i, right);               // swap with partition element
        return i;
    }
    // is x < y ?
    private static boolean less(double x, double y) {
        return (x < y);
    }
    // exchange a[i] and a[j]
    private static void exch(double[] a, int[] index, int i, int j) {
        double swap = a[i];
        a[i] = a[j];
        a[j] = swap;
        int b = index[i];
        index[i] = index[j];
        index[j] = b;
    }
}
